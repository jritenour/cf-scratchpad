require 'json'
require 'winrm'

  server = $evm.object['server']
  username = $evm.object['username']
  password = $evm.object.decrypt('password')


url_params = {
  :ipaddress => server,
  :port      => 5985                # Default port 5985
}

connect_params = {
  :user         => username,    # Example: domain\\user
  :pass         => password,
  :disable_sspi => true
}

url = "http://#{url_params[:ipaddress]}:#{url_params[:port]}/wsman"

winrm   = WinRM::WinRMWebService.new(url, :ssl, connect_params)
test=winrm.run_powershell_script("dir SQLSERVER:\\SQL\\WIN-EPFR9HFFJOV\\SQLEXPRESS\\Databases|select-object -expandproperty name")
dbs=test.stdout.split(' ')
$evm.log("info", "Listing DBs #{dbs}")

names=dbs.map{ |x| [x, x] }
$evm.log(:info, "Inspecting Resource Group  Names: #{names.inspect}")  

    dialog_field = $evm.object  
  
    # set the values  
    dialog_field['values'] = names.to_a
  
    # sort_by: value / description / none  
    dialog_field["sort_by"] = "description"  
    # sort_order: ascending / descending  
    dialog_field["sort_order"] = "ascending"  
    # data_type: string / integer  
    dialog_field["data_type"] = "string"  
    # required: true / false  
    dialog_field["required"] = "true"  
    $evm.log(:info, "Dynamic drop down values: #{dialog_field['values']}")  
